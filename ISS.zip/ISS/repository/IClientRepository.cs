﻿using ISS.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public interface IClientRepository:IRepository<string, Client>
    {
        public Client loginClient(string user, string password);
    }
}
