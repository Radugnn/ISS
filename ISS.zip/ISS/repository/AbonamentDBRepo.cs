﻿using ISS.Data;
using ISS.model;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public class AbonamentDBRepo : IAbonamentRepository
    {
        ISSContext context = new ISSContext();
        public void add(Abonament entity)
        {
            object[] param = new object[]
            {
             new SqlParameter("@tip", entity.Tip),
             new SqlParameter("@id", entity.Client.Id),
            };
            context.Database.ExecuteSqlRaw("Insert into Abonamente(Tip,ClientId) Values(@tip, @id)", param);
            context.SaveChanges();
        }

        public void delete(long idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Abonament> findAll()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Abonament> findByClient(string id)
        {
            var entities = context.ChangeTracker.Entries().ToArray(); for (int i = 0; i < entities.Length; i++) { entities[i].Reload(); }
            IEnumerable<Abonament> abonamente = context.Abonamente.Where(p => p.Client.Id == id).AsEnumerable();
            return abonamente;
        }

        public Abonament findOne(long idEntity)
        {
            throw new NotImplementedException();
        }
    }
}
