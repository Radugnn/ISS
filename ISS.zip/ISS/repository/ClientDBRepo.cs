﻿using ISS.Data;
using ISS.model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public class ClientDBRepo : IClientRepository
    {
        ISSContext context = new ISSContext();
        public void add(Client entity)
        {
            context.Clienti.Add(entity);
            context.SaveChanges();
        }

        public void delete(string idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Client> findAll()
        {
            throw new NotImplementedException();
        }

        public Client findOne(string nume)
        {
           Client client = context.Clienti.Where(c => c.Nume == nume).FirstOrDefault();
           return client;
        }

        public Client loginClient(string user, string password)
        {
            Client client = findOne(user);
            if (client == null)
                return null;
            if(client.Parola == password)
                return client;
            return null;
        }
    }
}
