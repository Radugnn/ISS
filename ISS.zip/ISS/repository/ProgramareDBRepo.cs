﻿using ISS.Data;
using ISS.model;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{

    public class ProgramareDBRepo : IProgramareRepository
    {
        ISSContext context = new ISSContext();
        public void add(Programare entity)
        {
            //context.Programari.Add(entity);
            object[] param = new object[]
            {
             new SqlParameter("@data", entity.Data),
             new SqlParameter("@id", entity.Client.Id),
             new SqlParameter("@status", entity.Status)
            };
            context.Database.ExecuteSqlRaw("Insert into Programari(Data,ClientId,Status) Values(@data, @id, @status)",param);
            //Debug.WriteLine(entity.Client.Id);
            context.SaveChanges();
        }

        public void delete(long idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Programare> findAll()
        {
            var entities = context.ChangeTracker.Entries().ToArray(); for (int i = 0; i < entities.Length; i++) { entities[i].Reload(); }
            IEnumerable<Programare> programari = context.Programari.AsEnumerable();
            List<Programare> ordered = programari.OrderByDescending(i => i.Id).ToList();
            return ordered;
        }

        public IEnumerable<Programare> findAllByClient(string id)
        {
            var entities = context.ChangeTracker.Entries().ToArray(); for (int i = 0; i < entities.Length; i++) { entities[i].Reload(); }
            IEnumerable<Programare> programari = context.Programari.Where(p => p.Client.Id == id).AsEnumerable();
            List<Programare> ordered = programari.OrderByDescending(i => i.Id).ToList();
            return ordered;
        }

        public IEnumerable<Programare> findByDate(DateTime date)
        {
            var entities = context.ChangeTracker.Entries().ToArray(); for (int i = 0; i < entities.Length; i++) { entities[i].Reload(); }
            IEnumerable<Programare> programari = context.Programari.Where(p => p.Data.Date == date.Date).AsEnumerable();
            List<Programare> ordered = programari.OrderByDescending(i => i.Id).ToList();
            return ordered;
        }

        public Programare findOne(long idEntity)
        {
            throw new NotImplementedException();
        }

        public void updateStatus(long id, string status)
        {
            //context.Programari.Update(entity);
            object[] param = new object[]
            {
             new SqlParameter("@status", status),
             new SqlParameter("@id", id)

            };
            context.Database.ExecuteSqlRaw("Update Programari Set Status=@status where Id=@id", param);
            //Debug.WriteLine(entity.Client.Id);
            context.SaveChanges();
        }
    }
}
