﻿using ISS.Data;
using ISS.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public class StaffDBRepo : IStaffRepository
    {
        ISSContext context = new ISSContext();
        public void add(Staff entity)
        {
            throw new NotImplementedException();
        }

        public void delete(string idEntity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Staff> findAll()
        {
            throw new NotImplementedException();
        }

        public Staff findOne(string idEntity)
        {
            Staff staff = context.Staffi.Find(idEntity);
            return staff;
        }

        public Staff loginStaff(string user, string password)
        {
            Staff staff = findOne(user);
            if (staff == null)
                return null;
            if (staff.Parola == password)
                return staff;
            return null;
        }
    }
}
