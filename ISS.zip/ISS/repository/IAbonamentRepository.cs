﻿using ISS.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public interface IAbonamentRepository : IRepository<long, Abonament>
    {
        IEnumerable<Abonament> findByClient(string id);
    }
}
