﻿using ISS.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.repository
{
    public interface IProgramareRepository : IRepository<long, Programare>
    {
        IEnumerable<Programare> findAllByClient(string id);
        void updateStatus(long id, string status);
        IEnumerable<Programare> findByDate( DateTime date);
    }
}
