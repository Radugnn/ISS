﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.model
{
    public class Programare : Entity<long>
    {
        public DateTime Data { get; set; }
        public Client Client { get; set; } = null!;
        public string Status { get; set; }
        public Programare() : base(0)
        {
        }
        public Programare(long id, DateTime data, Client client, string status): base(id)
        {

            Data = data;
            Client = client;
            Status = status;
        }
    }
}
