﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.model
{
    public class Client : Entity<string>
    {
        public string Nume { get; set; }
        public string Parola { get; set; }

        public Client(string id, string nume, string parola): base(id)
        {
            Nume = nume;
            Parola = parola;
        }
    }
}
