﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace ISS.model
{
    public class Staff:Entity<string>
    {
        public string Parola { get; set; }

        public Staff(string id, string parola) : base(id)
        {
            Parola = parola;
        }
    }
}
