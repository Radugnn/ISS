﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.model
{
    public class Abonament : Entity<long>
    {
        public string Tip { get; set; }

        public Client Client { get; set; } = null!;

        public Abonament():base(0)
        {
        }

        public Abonament(long Id, string tip, Client client): base(Id)
        {
            Tip = tip;
            Client = client;
        }
    }
}
