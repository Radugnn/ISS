﻿namespace ISS
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonShowProgramari = new System.Windows.Forms.Button();
            this.dataGridViewProgramari = new System.Windows.Forms.DataGridView();
            this.TimePickerProgramare = new System.Windows.Forms.DateTimePicker();
            this.buttonProgrameaza = new System.Windows.Forms.Button();
            this.buttonAnuleaza = new System.Windows.Forms.Button();
            this.buttonAbonamente = new System.Windows.Forms.Button();
            this.dataGridViewAbonamente = new System.Windows.Forms.DataGridView();
            this.comboBoxAbonamente = new System.Windows.Forms.ComboBox();
            this.buttonCumparaAbonament = new System.Windows.Forms.Button();
            this.dateTimePickerProgramare = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProgramari)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAbonamente)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonShowProgramari
            // 
            this.buttonShowProgramari.Location = new System.Drawing.Point(38, 63);
            this.buttonShowProgramari.Name = "buttonShowProgramari";
            this.buttonShowProgramari.Size = new System.Drawing.Size(87, 45);
            this.buttonShowProgramari.TabIndex = 0;
            this.buttonShowProgramari.Text = "Programari";
            this.buttonShowProgramari.UseVisualStyleBackColor = true;
            this.buttonShowProgramari.Click += new System.EventHandler(this.buttonShowProgramari_Click);
            // 
            // dataGridViewProgramari
            // 
            this.dataGridViewProgramari.AllowUserToAddRows = false;
            this.dataGridViewProgramari.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProgramari.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProgramari.Location = new System.Drawing.Point(225, 149);
            this.dataGridViewProgramari.Name = "dataGridViewProgramari";
            this.dataGridViewProgramari.RowHeadersVisible = false;
            this.dataGridViewProgramari.RowHeadersWidth = 51;
            this.dataGridViewProgramari.RowTemplate.Height = 25;
            this.dataGridViewProgramari.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProgramari.Size = new System.Drawing.Size(303, 126);
            this.dataGridViewProgramari.TabIndex = 1;
            // 
            // TimePickerProgramare
            // 
            this.TimePickerProgramare.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TimePickerProgramare.Location = new System.Drawing.Point(430, 33);
            this.TimePickerProgramare.MinDate = new System.DateTime(2023, 5, 27, 0, 0, 0, 0);
            this.TimePickerProgramare.Name = "TimePickerProgramare";
            this.TimePickerProgramare.Size = new System.Drawing.Size(96, 23);
            this.TimePickerProgramare.TabIndex = 2;
            // 
            // buttonProgrameaza
            // 
            this.buttonProgrameaza.Location = new System.Drawing.Point(430, 69);
            this.buttonProgrameaza.Name = "buttonProgrameaza";
            this.buttonProgrameaza.Size = new System.Drawing.Size(97, 34);
            this.buttonProgrameaza.TabIndex = 3;
            this.buttonProgrameaza.Text = "Programeaza";
            this.buttonProgrameaza.UseVisualStyleBackColor = true;
            this.buttonProgrameaza.Click += new System.EventHandler(this.buttonProgrameaza_Click);
            // 
            // buttonAnuleaza
            // 
            this.buttonAnuleaza.BackColor = System.Drawing.Color.LightCoral;
            this.buttonAnuleaza.Location = new System.Drawing.Point(319, 280);
            this.buttonAnuleaza.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAnuleaza.Name = "buttonAnuleaza";
            this.buttonAnuleaza.Size = new System.Drawing.Size(118, 32);
            this.buttonAnuleaza.TabIndex = 4;
            this.buttonAnuleaza.Text = "Anuleaza";
            this.buttonAnuleaza.UseVisualStyleBackColor = false;
            this.buttonAnuleaza.Click += new System.EventHandler(this.buttonAnuleaza_Click);
            // 
            // buttonAbonamente
            // 
            this.buttonAbonamente.Location = new System.Drawing.Point(38, 128);
            this.buttonAbonamente.Name = "buttonAbonamente";
            this.buttonAbonamente.Size = new System.Drawing.Size(87, 44);
            this.buttonAbonamente.TabIndex = 5;
            this.buttonAbonamente.Text = "Abonamente";
            this.buttonAbonamente.UseVisualStyleBackColor = true;
            this.buttonAbonamente.Click += new System.EventHandler(this.buttonAbonamente_Click);
            // 
            // dataGridViewAbonamente
            // 
            this.dataGridViewAbonamente.AllowUserToAddRows = false;
            this.dataGridViewAbonamente.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAbonamente.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridViewAbonamente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAbonamente.Location = new System.Drawing.Point(225, 63);
            this.dataGridViewAbonamente.Name = "dataGridViewAbonamente";
            this.dataGridViewAbonamente.RowHeadersVisible = false;
            this.dataGridViewAbonamente.RowTemplate.Height = 25;
            this.dataGridViewAbonamente.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAbonamente.Size = new System.Drawing.Size(303, 150);
            this.dataGridViewAbonamente.TabIndex = 7;
            // 
            // comboBoxAbonamente
            // 
            this.comboBoxAbonamente.FormattingEnabled = true;
            this.comboBoxAbonamente.Location = new System.Drawing.Point(225, 252);
            this.comboBoxAbonamente.Name = "comboBoxAbonamente";
            this.comboBoxAbonamente.Size = new System.Drawing.Size(140, 23);
            this.comboBoxAbonamente.TabIndex = 8;
            // 
            // buttonCumparaAbonament
            // 
            this.buttonCumparaAbonament.Location = new System.Drawing.Point(428, 236);
            this.buttonCumparaAbonament.Name = "buttonCumparaAbonament";
            this.buttonCumparaAbonament.Size = new System.Drawing.Size(98, 53);
            this.buttonCumparaAbonament.TabIndex = 9;
            this.buttonCumparaAbonament.Text = "Cumpara Abonament";
            this.buttonCumparaAbonament.UseVisualStyleBackColor = true;
            this.buttonCumparaAbonament.Click += new System.EventHandler(this.buttonCumparaAbonament_Click);
            // 
            // dateTimePickerProgramare
            // 
            this.dateTimePickerProgramare.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerProgramare.Location = new System.Drawing.Point(319, 33);
            this.dateTimePickerProgramare.MinDate = new System.DateTime(2023, 5, 27, 0, 0, 0, 0);
            this.dateTimePickerProgramare.Name = "dateTimePickerProgramare";
            this.dateTimePickerProgramare.Size = new System.Drawing.Size(96, 23);
            this.dateTimePickerProgramare.TabIndex = 10;
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 338);
            this.Controls.Add(this.dateTimePickerProgramare);
            this.Controls.Add(this.buttonCumparaAbonament);
            this.Controls.Add(this.comboBoxAbonamente);
            this.Controls.Add(this.dataGridViewAbonamente);
            this.Controls.Add(this.buttonAbonamente);
            this.Controls.Add(this.buttonAnuleaza);
            this.Controls.Add(this.buttonProgrameaza);
            this.Controls.Add(this.TimePickerProgramare);
            this.Controls.Add(this.dataGridViewProgramari);
            this.Controls.Add(this.buttonShowProgramari);
            this.Name = "ClientForm";
            this.Text = "ClientForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProgramari)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAbonamente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Button buttonShowProgramari;
        private DataGridView dataGridViewProgramari;
        private DateTimePicker TimePickerProgramare;
        private Button buttonProgrameaza;
        private Button buttonAnuleaza;
        private Button buttonAbonamente;
        private DataGridView dataGridViewAbonamente;
        private ComboBox comboBoxAbonamente;
        private Button buttonCumparaAbonament;
        private DateTimePicker dateTimePickerProgramare;
    }
}