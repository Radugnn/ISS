using ISS.repository;
using ISS.service;

namespace ISS
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            IClientRepository clientRepository = new ClientDBRepo();
            IStaffRepository staffRepository = new StaffDBRepo();
            IProgramareRepository programareRepository = new ProgramareDBRepo();
            IAbonamentRepository abonamentRepository = new AbonamentDBRepo();
            Service service = new Service(clientRepository, staffRepository, programareRepository, abonamentRepository);
            Application.Run(new LoginForm(service));
        }
    }
}