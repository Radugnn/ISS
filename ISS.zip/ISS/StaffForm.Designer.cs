﻿namespace ISS
{
    partial class StaffForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FormularInregistrareButton = new System.Windows.Forms.Button();
            this.textBoxCNP = new System.Windows.Forms.TextBox();
            this.textBoxNume = new System.Windows.Forms.TextBox();
            this.textBoxParola = new System.Windows.Forms.TextBox();
            this.labelCNP = new System.Windows.Forms.Label();
            this.labelNume = new System.Windows.Forms.Label();
            this.labelParola = new System.Windows.Forms.Label();
            this.buttonInregistrare = new System.Windows.Forms.Button();
            this.buttonProgramari = new System.Windows.Forms.Button();
            this.dataGridViewAllProgramari = new System.Windows.Forms.DataGridView();
            this.dateTimePickerProgramari = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllProgramari)).BeginInit();
            this.SuspendLayout();
            // 
            // FormularInregistrareButton
            // 
            this.FormularInregistrareButton.Location = new System.Drawing.Point(66, 91);
            this.FormularInregistrareButton.Name = "FormularInregistrareButton";
            this.FormularInregistrareButton.Size = new System.Drawing.Size(156, 55);
            this.FormularInregistrareButton.TabIndex = 0;
            this.FormularInregistrareButton.Text = "Inregistrare Client";
            this.FormularInregistrareButton.UseVisualStyleBackColor = true;
            this.FormularInregistrareButton.Click += new System.EventHandler(this.FormularInregistrareButton_Click);
            // 
            // textBoxCNP
            // 
            this.textBoxCNP.Location = new System.Drawing.Point(596, 91);
            this.textBoxCNP.Name = "textBoxCNP";
            this.textBoxCNP.Size = new System.Drawing.Size(100, 23);
            this.textBoxCNP.TabIndex = 1;
            // 
            // textBoxNume
            // 
            this.textBoxNume.Location = new System.Drawing.Point(596, 180);
            this.textBoxNume.Name = "textBoxNume";
            this.textBoxNume.Size = new System.Drawing.Size(100, 23);
            this.textBoxNume.TabIndex = 2;
            // 
            // textBoxParola
            // 
            this.textBoxParola.Location = new System.Drawing.Point(596, 139);
            this.textBoxParola.Name = "textBoxParola";
            this.textBoxParola.Size = new System.Drawing.Size(100, 23);
            this.textBoxParola.TabIndex = 3;
            // 
            // labelCNP
            // 
            this.labelCNP.AutoSize = true;
            this.labelCNP.Location = new System.Drawing.Point(519, 94);
            this.labelCNP.Name = "labelCNP";
            this.labelCNP.Size = new System.Drawing.Size(31, 15);
            this.labelCNP.TabIndex = 4;
            this.labelCNP.Text = "CNP";
            // 
            // labelNume
            // 
            this.labelNume.AutoSize = true;
            this.labelNume.Location = new System.Drawing.Point(519, 139);
            this.labelNume.Name = "labelNume";
            this.labelNume.Size = new System.Drawing.Size(40, 15);
            this.labelNume.TabIndex = 5;
            this.labelNume.Text = "Nume";
            // 
            // labelParola
            // 
            this.labelParola.AutoSize = true;
            this.labelParola.Location = new System.Drawing.Point(519, 183);
            this.labelParola.Name = "labelParola";
            this.labelParola.Size = new System.Drawing.Size(40, 15);
            this.labelParola.TabIndex = 6;
            this.labelParola.Text = "Parola";
            // 
            // buttonInregistrare
            // 
            this.buttonInregistrare.Location = new System.Drawing.Point(596, 231);
            this.buttonInregistrare.Name = "buttonInregistrare";
            this.buttonInregistrare.Size = new System.Drawing.Size(100, 33);
            this.buttonInregistrare.TabIndex = 7;
            this.buttonInregistrare.Text = "Inregistrare";
            this.buttonInregistrare.UseVisualStyleBackColor = true;
            this.buttonInregistrare.Click += new System.EventHandler(this.buttonInregistrare_Click);
            // 
            // buttonProgramari
            // 
            this.buttonProgramari.Location = new System.Drawing.Point(66, 166);
            this.buttonProgramari.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonProgramari.Name = "buttonProgramari";
            this.buttonProgramari.Size = new System.Drawing.Size(156, 47);
            this.buttonProgramari.TabIndex = 8;
            this.buttonProgramari.Text = "Programari";
            this.buttonProgramari.UseVisualStyleBackColor = true;
            this.buttonProgramari.Click += new System.EventHandler(this.buttonProgramari_Click);
            // 
            // dataGridViewAllProgramari
            // 
            this.dataGridViewAllProgramari.AllowUserToAddRows = false;
            this.dataGridViewAllProgramari.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAllProgramari.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAllProgramari.Location = new System.Drawing.Point(373, 91);
            this.dataGridViewAllProgramari.Name = "dataGridViewAllProgramari";
            this.dataGridViewAllProgramari.RowHeadersVisible = false;
            this.dataGridViewAllProgramari.RowTemplate.Height = 25;
            this.dataGridViewAllProgramari.Size = new System.Drawing.Size(363, 232);
            this.dataGridViewAllProgramari.TabIndex = 9;
            // 
            // dateTimePickerProgramari
            // 
            this.dateTimePickerProgramari.Location = new System.Drawing.Point(463, 45);
            this.dateTimePickerProgramari.Name = "dateTimePickerProgramari";
            this.dateTimePickerProgramari.Size = new System.Drawing.Size(200, 23);
            this.dateTimePickerProgramari.TabIndex = 10;
            this.dateTimePickerProgramari.ValueChanged += new System.EventHandler(this.dateChosen);
            // 
            // StaffForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePickerProgramari);
            this.Controls.Add(this.dataGridViewAllProgramari);
            this.Controls.Add(this.buttonProgramari);
            this.Controls.Add(this.buttonInregistrare);
            this.Controls.Add(this.labelParola);
            this.Controls.Add(this.labelNume);
            this.Controls.Add(this.labelCNP);
            this.Controls.Add(this.textBoxParola);
            this.Controls.Add(this.textBoxNume);
            this.Controls.Add(this.textBoxCNP);
            this.Controls.Add(this.FormularInregistrareButton);
            this.Name = "StaffForm";
            this.Text = "StaffForm";
            this.Load += new System.EventHandler(this.StaffForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAllProgramari)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button FormularInregistrareButton;
        private TextBox textBoxCNP;
        private TextBox textBoxNume;
        private TextBox textBoxParola;
        private Label labelCNP;
        private Label labelNume;
        private Label labelParola;
        private Button buttonInregistrare;
        private Button buttonProgramari;
        private DataGridView dataGridViewProgramari;
        private DataGridView dataGridViewAllProgramari;
        private DateTimePicker dateTimePickerProgramari;
    }
}