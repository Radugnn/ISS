﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.Utils
{
    public class UpdateEventArgs : EventArgs
    {
        private readonly Object[] data;

        public UpdateEventArgs(object[] data)
        {
            this.data=data;
        }

        public object[] Data
        {
            get { return data; }
        }
    }
}
