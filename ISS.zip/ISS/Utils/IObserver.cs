﻿using ISS.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.Utils
{
    public interface IObserver
    {
        void ProgramariActualizate(IEnumerable<Programare> all);
    }
}
