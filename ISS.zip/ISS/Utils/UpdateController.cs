﻿using ISS.model;
using ISS.service;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.Utils
{
    public class UpdateController : IObserver
    {
        public event EventHandler<UpdateEventArgs> updateEvent;
        private readonly Service service;
        //private Persoana currentUser;

        public UpdateController(Service service)
        {
            this.service=service;
          // this.currentUser=currentUser;
        }


        protected void OnEvent(UpdateEventArgs args)
        {
            if (updateEvent == null) return;
                updateEvent(this, args);
            Debug.WriteLine("Update Event called");
        }

        public void ProgramariActualizate(IEnumerable<Programare> all)
        {
            Debug.WriteLine("Programare Update Controller");
            UpdateEventArgs args = new UpdateEventArgs(new object[] { all });
            OnEvent(args);
        }
    }
}
