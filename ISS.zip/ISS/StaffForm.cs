﻿using ISS.model;
using ISS.repository;
using ISS.service;
using ISS.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISS
{
    public partial class StaffForm : Form, IObserver
    {
        private Service service;
        private UpdateController ctrl;
        public StaffForm(Service service, UpdateController u)
        {
            this.service = service;
            ctrl = u;
            InitializeComponent();     


        }
        public delegate void UpdateGridViewCallback(DataGridView d1, IEnumerable<Programare> list);
        public void update(object sender, UpdateEventArgs args)
        {

            Debug.WriteLine("Updating programari in UI");
            dataGridViewAllProgramari.BeginInvoke(new UpdateGridViewCallback(this.UpdateGridView), new object[] { dataGridViewAllProgramari, (IEnumerable<Programare>)args.Data[0] });

        }
        public void UpdateGridView(DataGridView d1, IEnumerable<Programare> list)
        {
            Debug.WriteLine("UPDATEGRIDVIEW");
            d1.DataSource = null;
            d1.DataSource = list.ToList();
        }
        public void setInitialData()
        {
            this.ctrl.updateEvent += update;
            hideFormular();
            hideDataGrid();
        }
        private void hideFormular()
        {
            labelCNP.Visible = false;
            labelNume.Visible = false;
            labelParola.Visible = false;
            textBoxCNP.Visible=false;
            textBoxNume.Visible=false;
            textBoxParola.Visible=false;
            buttonInregistrare.Visible=false;
        }
        private void showFormular()
        {
            labelCNP.Visible = true;
            labelNume.Visible = true;
            labelParola.Visible = true;
            textBoxCNP.Visible = true;
            textBoxNume.Visible = true;
            textBoxParola.Visible = true;
            buttonInregistrare.Visible = true;
        }
        private void hideDataGrid()
        {
            dateTimePickerProgramari.Visible = false;
            dataGridViewAllProgramari.Visible = false;
        }
        private void showDataGrid()
        {
            dateTimePickerProgramari.Visible = true;
            dataGridViewAllProgramari.Visible = true;
        }
        private void loadProgramari()
        {
            
            List<Programare> listOfProgramari = this.service.findProgramari().ToList();

            dataGridViewAllProgramari.DataSource = listOfProgramari;
          //  dataGridViewAllProgramari.Columns[1].Width = 0;
        }
        private void FormularInregistrareButton_Click(object sender, EventArgs e)
        {
            hideDataGrid();
            showFormular();
        }

        private void buttonInregistrare_Click(object sender, EventArgs e)
        {
            string cnp = textBoxCNP.Text;
            string nume = textBoxNume.Text;
            string parola = textBoxParola.Text;
            service.addClient(cnp,nume, parola);
            MessageBox.Show("Client inregistrat!");
        }

        private void buttonProgramari_Click(object sender, EventArgs e)
        {
            hideFormular();
            showDataGrid();
            loadProgramari();
        }

        private void dataGridViewProgramari_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void StaffForm_Load(object sender, EventArgs e)
        {

        }

        public void ProgramariActualizate(IEnumerable<Programare> all)
        {
            throw new NotImplementedException();
        }

        private void dateChosen(object sender, EventArgs e)
        {
            DateTime date = dateTimePickerProgramari.Value;
            List<Programare> listOfProgramari = this.service.findProgramariByDate(date).ToList();

            dataGridViewAllProgramari.DataSource = listOfProgramari;
        }
    }
}
