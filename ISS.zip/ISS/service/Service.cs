﻿using ISS.model;
using ISS.repository;
using ISS.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISS.service
{
    public class Service
    {
        private IClientRepository clientRepository;
        private IStaffRepository staffRepository;
        private IProgramareRepository programareRepository;
        private IAbonamentRepository abonamentRepository;
        private readonly IList<IObserver> loggedClients;

        public Service(IClientRepository clientRepository, IStaffRepository staffRepository, IProgramareRepository programareRepository, IAbonamentRepository abonamentRepository)
        {
            this.clientRepository = clientRepository;
            this.staffRepository = staffRepository;
            this.programareRepository = programareRepository;
            this.abonamentRepository = abonamentRepository;
            this.loggedClients = new List<IObserver>();
        }
        public Client loginClient(String user, String password, IObserver client)
        {
            Client p = clientRepository.loginClient(user, password);
            if (p == null)
                throw new Exception("Date login incorecte");
            loggedClients.Add(client);
            return p;
        }
        public Staff loginStaff(String user, String password, IObserver client)
        {
            Staff p = staffRepository.loginStaff(user, password);
            if (p == null)
                throw new Exception("Date login incorecte");
            loggedClients.Add(client);
            return p;
        }
        public void addClient(string cnp, string nume, string parola)
        {
            Client c = new Client(cnp,nume, parola);
            clientRepository.add(c);
        }

        public Client findOneClient(string user)
        {
            return clientRepository.findOne(user);
        }

        public void addProgramare(DateTime date, Client client)
        {
            long id = new Random().Next(0, 100000000);
            Programare p = new Programare(id, date, client,"CONFIRMAT");
            programareRepository.add(p);
            this.notifyUpdate();
        }
        public void updateStatusProgramare(long id, string status)
        {
            programareRepository.updateStatus(id,status);
            this.notifyUpdate();
        }
        public IEnumerable<Programare> findProgramariByClient(Client client)
        {
            return programareRepository.findAllByClient(client.Id);
        }
        public IEnumerable<Programare> findProgramari()
        {
            return programareRepository.findAll();
        }
        public void notifyUpdate()
        {
            IEnumerable<Programare> all = findProgramari();
            try
            {
                foreach (IObserver obs in loggedClients)
                {
                    Console.WriteLine("Notifying : " + obs.ToString());
                    Task.Run(() => obs.ProgramariActualizate(all));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + "[NotifyInscriere]");
            }
        }

        public IEnumerable<Abonament> findAbonamenteByClient(Client client)
        {
            return abonamentRepository.findByClient(client.Id);
        }

        public void addAbonament(string tipAbonament, Client client)
        {
           Abonament abonament = new Abonament(1,tipAbonament,client);
           abonamentRepository.add(abonament);

        }

        public IEnumerable<Programare> findProgramariByDate(DateTime date)
        {
            return programareRepository.findByDate(date);
        }
    }
}
