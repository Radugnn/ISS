﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ISS.model;
using Microsoft.EntityFrameworkCore;
namespace ISS.Data
{
    public class ISSContext : DbContext
    {
        public DbSet<Client> Clienti { get; set; } = null!;
        public DbSet<Staff> Staffi { get; set; } = null!;
        public DbSet<Programare> Programari { get; set; } = null!;
        public DbSet<Abonament> Abonamente { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ISS;Integrated Security=True;");
        }
    }
}
