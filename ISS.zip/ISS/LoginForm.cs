﻿using ISS.repository;
using ISS.service;
using ISS.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISS
{
    public partial class LoginForm : Form
    {
        private Service service;
        public LoginForm(Service service)
        {
            this.service = service;
            InitializeComponent();

        }
        public void loginStaff()
        {
            string user = textBoxUsername.Text;
            string parola = textBoxParola.Text;
            UpdateController ctrl = new UpdateController(service);
            service.loginStaff(user, parola, ctrl);
            StaffForm formStaff = new StaffForm(service, ctrl);
            formStaff.setInitialData();
            formStaff.Show();
        }
        public void loginClient()
        {
            string user = textBoxUsername.Text;
            string parola = textBoxParola.Text;
            UpdateController ctrl = new UpdateController(service);
            service.loginClient(user, parola, ctrl);
            ClientForm formClient = new ClientForm(service, service.findOneClient(user), ctrl);
            formClient.Show();
        }
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string user = textBoxUsername.Text;
            string parola = textBoxParola.Text;
            UpdateController ctrl = new UpdateController(service);
            try
            {

                loginStaff();
            }
            catch (Exception ex)
            {
                try
                {
                    loginClient();
                }
                catch(Exception ex2)
                {
                    MessageBox.Show(ex2.Message);
                }
            }
        }
    }
}
