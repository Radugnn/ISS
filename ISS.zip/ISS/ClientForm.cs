﻿using ISS.model;
using ISS.repository;
using ISS.service;
using ISS.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISS
{
    public partial class ClientForm : Form
    {
        private Service service { get; set; }
        Client client { get; set; }
        private UpdateController ctrl;
        public ClientForm(Service service, Client c, UpdateController u)
        {
            client = c;
            this.service = service;
            ctrl = u;
            InitializeComponent();
            
            hideProgramari();
            hideAbonamente();
        }

        private void buttonShowProgramari_Click(object sender, EventArgs e)
        {
            showProgramari();
            loadProgramari();
        }

        private void hideProgramari()
        {
            dataGridViewProgramari.Visible = false;
            dateTimePickerProgramare.Visible = false;
            TimePickerProgramare.Visible = false;
            buttonProgrameaza.Visible = false;
            buttonAnuleaza.Visible = false;
        }
        private void showProgramari()
        {
            hideAbonamente();
            dataGridViewProgramari.Visible = true;
            TimePickerProgramare.Visible = true;
            dateTimePickerProgramare.Visible = true;
            buttonProgrameaza.Visible = true;
            buttonAnuleaza.Visible = true;

        }
        private void hideAbonamente()
        {
            dataGridViewAbonamente.Visible = false;
            comboBoxAbonamente.Visible = false;
            buttonCumparaAbonament.Visible = false;
        }
        private void showAbonamente()
        {
            dataGridViewAbonamente.Visible = true;
            comboBoxAbonamente.Visible = true;
            buttonCumparaAbonament.Visible = true;
        }
        private void loadProgramari()
        {
  
            List<Programare> listOfProgramari = this.service.findProgramariByClient(client).ToList();
            //Debug.WriteLine(listOfProgramari.Last().Status);
            dataGridViewProgramari.DataSource = listOfProgramari;
            dataGridViewProgramari.Columns["Client"].Visible = false;
            TimePickerProgramare.Format = DateTimePickerFormat.Custom;
            TimePickerProgramare.CustomFormat = "HH:mm tt";
            TimePickerProgramare.ShowUpDown = true;
        }
        private void buttonProgrameaza_Click(object sender, EventArgs e)
        {
            DateTime date = dateTimePickerProgramare.Value;
            DateTime time = TimePickerProgramare.Value;
            date = date.Date.AddHours(time.Hour).AddMinutes(time.Minute);

            service.addProgramare(date, client);
            loadProgramari();
        }

        private void buttonAnuleaza_Click(object sender, EventArgs e)
        {
            Debug.WriteLine(dataGridViewProgramari.CurrentRow.Cells[3].Value);
            long id = long.Parse(dataGridViewProgramari.CurrentRow.Cells[3].Value.ToString());
            service.updateStatusProgramare(id,"ANULAT");
            //MessageBox.Show("Programare Anulata");
            loadProgramari();
        }

        private void buttonAbonamente_Click(object sender, EventArgs e)
        {
            hideProgramari();
            loadAbonamente();
            showAbonamente();

        }

        private void loadAbonamente()
        {

            List<Abonament> listOfAbonamente = this.service.findAbonamenteByClient(client).ToList();
            //Debug.WriteLine(listOfProgramari.Last().Status);
            dataGridViewAbonamente.DataSource = listOfAbonamente;
            List<string> tipuriAbonament = new List<string> { "Fitness", "Aerobic", "Kickbox", "Studenti", "Full" };
            comboBoxAbonamente.DataSource = tipuriAbonament;
        }

        private void buttonCumparaAbonament_Click(object sender, EventArgs e)
        {
            string tipAbonament = comboBoxAbonamente.Text;
            service.addAbonament(tipAbonament, client);
            loadAbonamente();
        }
    }
}
